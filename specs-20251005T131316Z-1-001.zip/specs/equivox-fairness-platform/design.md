# Design Document

## Overview

Equivox is implemented as a single Jupyter notebook that processes Urdu audio clips to provide bias-free hiring evaluations. The system uses a multi-stage pipeline: audio preprocessing, feature extraction using both traditional signal processing and modern transformer models, adversarial debiasing, and fairness scoring. The design prioritizes simplicity and local deployment while maintaining effectiveness for Urdu language processing.

## Architecture

The system follows a modular pipeline architecture within a single notebook:

```mermaid
graph TD
    A[Audio Input] --> B[Preprocessing]
    B --> C[Feature Extraction]
    C --> D[Bias Removal]
    D --> E[Clarity Scoring]
    E --> F[Visualization]
    F --> G[Results Display]
    
    C --> C1[Librosa Features]
    C --> C2[wav2vec2 Features]
    C1 --> D
    C2 --> D
```

### Core Components

1. **Audio Preprocessor**: Handles file loading, normalization, and format conversion
2. **Feature Extractor**: Combines traditional audio features with transformer embeddings
3. **Bias Remover**: Applies adversarial debiasing and feature normalization
4. **Clarity Scorer**: Generates fairness-based evaluation scores
5. **Visualizer**: Creates UMAP plots and bias heatmaps
6. **Web Interface**: Simple upload and display interface

## Components and Interfaces

### 1. Audio Preprocessing Module

**Purpose**: Load and normalize audio files for consistent processing

**Interface**:
```python
def preprocess_audio(file_path: str) -> Tuple[np.ndarray, int]:
    """
    Load and normalize audio file
    Returns: (audio_data, sample_rate)
    """
```

**Implementation**:
- Uses librosa for audio loading
- Normalizes to 16kHz sample rate
- Applies noise reduction if needed
- Handles various audio formats (wav, mp3, m4a)

### 2. Feature Extraction Module

**Purpose**: Extract both traditional and modern speech features

**Interface**:
```python
def extract_features(audio: np.ndarray, sr: int) -> Dict[str, np.ndarray]:
    """
    Extract comprehensive feature set
    Returns: Dictionary with feature categories
    """
```

**Traditional Features (Librosa)**:
- MFCC (13 coefficients)
- Spectral centroid, rolloff, bandwidth
- Zero crossing rate
- Chroma features
- Prosodic features (pitch, rhythm, intensity)

**Modern Features (wav2vec2-xlsr-53)**:
- Contextual speech representations
- Language-agnostic semantic features
- Temporal dynamics

### 3. Bias Removal Module

**Purpose**: Remove demographic and accent-based biases from features

**Interface**:
```python
def remove_bias(features: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
    """
    Apply unsupervised debiasing to features
    Returns: Debiased feature set
    """
```

**Techniques**:
- **Unsupervised Normalization**: Statistical normalization to reduce demographic correlations
- **Feature Filtering**: Remove pitch-based and voice quality features that correlate with demographics
- **Prosodic Filtering**: Focus on content-related prosodic patterns only
- **Accent Neutralization**: Focus on content structure rather than pronunciation patterns

### 4. Clarity Scoring Module

**Purpose**: Generate fairness-based evaluation scores

**Interface**:
```python
def calculate_clarity_score(debiased_features: Dict[str, np.ndarray]) -> float:
    """
    Calculate clarity score from debiased features
    Returns: Score between 0-100
    """
```

**Scoring Factors**:
- Speech fluency (pause patterns, rhythm consistency)
- Articulation clarity (consonant/vowel distinction)
- Content structure (logical flow indicators)
- Confidence markers (hesitation patterns)

## Data Models

### Audio Data Structure
```python
@dataclass
class AudioSample:
    file_path: str
    audio_data: np.ndarray
    sample_rate: int
    duration: float
```

### Feature Vector Structure
```python
@dataclass
class FeatureSet:
    traditional_features: np.ndarray  # Shape: (n_features,)
    transformer_features: np.ndarray  # Shape: (hidden_dim,)
    prosodic_features: np.ndarray     # Shape: (prosodic_dim,)
```

### Evaluation Result Structure
```python
@dataclass
class EvaluationResult:
    clarity_score: float
    bias_metrics: Dict[str, float]
    feature_importance: Dict[str, float]
    confidence_interval: Tuple[float, float]
```

## Error Handling

### Audio Processing Errors
- **File Format Issues**: Automatic conversion using librosa/soundfile
- **Corrupted Audio**: Skip and log problematic files
- **Length Validation**: Ensure 3-8 second constraint

### Model Loading Errors
- **Network Issues**: Graceful fallback to cached models
- **Memory Constraints**: Use model quantization if needed
- **Missing Dependencies**: Clear error messages with installation instructions

### Feature Extraction Errors
- **Silent Audio**: Return zero features with warning
- **Processing Failures**: Log errors and continue with available features

## Testing Strategy

### Unit Tests
1. **Audio Preprocessing**: Test with various formats and sample rates
2. **Feature Extraction**: Validate feature dimensions and ranges
3. **Bias Removal**: Test with synthetic biased data
4. **Scoring**: Verify score ranges and consistency

### Integration Tests
1. **End-to-End Pipeline**: Process sample Urdu audio files
2. **Bias Effectiveness**: Compare scores across gender groups
3. **Performance**: Measure processing time for 3-8 second clips

### Validation Tests
1. **Urdu Language Support**: Test with native Urdu speakers
2. **Cross-Gender Fairness**: Validate equal treatment across genders
3. **Accent Robustness**: Test with different regional accents

### Demo Validation
1. **Upload Interface**: Test file upload and processing
2. **Visualization**: Verify UMAP and heatmap generation
3. **Results Display**: Check score presentation and explanations

## Implementation Approach

### Phase 1: Core Pipeline
- Set up Jupyter notebook environment
- Implement audio preprocessing and basic feature extraction
- Create simple scoring mechanism

### Phase 2: Advanced Features
- Integrate wav2vec2-xlsr-53 model
- Implement adversarial debiasing
- Add visualization components

### Phase 3: Interface and Demo
- Create upload interface using ipywidgets
- Add interactive visualizations
- Implement results display

### Dependencies
```python
# Core audio processing
librosa>=0.9.0
soundfile>=0.10.0
scipy>=1.7.0

# Machine learning
transformers>=4.20.0
torch>=1.12.0
scikit-learn>=1.1.0
numpy>=1.21.0

# Visualization
matplotlib>=3.5.0
seaborn>=0.11.0
umap-learn>=0.5.0
plotly>=5.0.0

# Notebook interface
ipywidgets>=7.6.0
IPython>=7.0.0
```

## Performance Considerations

### Memory Optimization
- Process audio files individually to avoid memory buildup
- Use model quantization for transformer models
- Implement feature caching for repeated processing

### Processing Speed
- Batch process multiple files when possible
- Use CPU-optimized versions of models
- Implement progress bars for user feedback

### Storage Requirements
- Model cache: ~300MB for wav2vec2-base-xlsr-53
- Feature cache: ~1MB per 100 audio files
- Results storage: Minimal JSON output